<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FONRIO - Sistema web de inventarios</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <!-- Font Awesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="imagen" href="Imagenes/Logo.webp">
</head>
<body>
    <div class="contenedor-aplicacion">

        <!-- Barra lateral -->
        <nav class="barra-lateral">
            <div class="encabezado-barra-lateral">
                <span class="texto-logotipo">TECNICELL RM</span>
            </div>

            <div class="menu-barra-lateral">

                <div class="seccion-menu">
                    <div class="elemento-menu activo">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </div>
                    <a href="../html/Compra.html" class="elemento-menu">
    <i class="fas fa-shopping-cart"></i>
    <span>Compras</span>
</a>
                    <div class="elemento-menu">
                        <i class="fas fa-truck"></i>
                        <span>Recibidos</span>
                    </div>
                    <a href="../html/Devoluciones.html" class="elemento-menu">
    <i class="fas fa-undo"></i>
    <span>Devoluciones</span>
</a>
                    <div class="elemento-menu">
                        <i class="fas fa-cube"></i>
                        <span>Stocks</span>
                    </div>
                    <div class="elemento-menu">
                        <i class="fas fa-chart-line"></i>
                        <span>Ventas</span>
                    </div>
                </div>

                <div class="seccion-menu">
                    <div class="titulo-menu">Mantenimiento</div>
                    <div class="elemento-menu">

                        <a href="../html/proveedores.html"  class="elemento-menu">
                        <i class="fas fa-users"></i>
                        <span>Proveedores</span></a>
                    </div>
                    <div class="elemento-menu">
                        <i class="fas fa-boxes"></i>
                        <span>Productos</span>
                    </div>
                    <div class="elemento-menu">
                        <i class="fas fa-user-friends"></i>
                        <span>Usuarios</span>
                    </div>
                    <div class="elemento-menu">
                        <i class="fas fa-cog"></i>
                        <span>Configuración</span>
                    </div>
                </div>

            </div>
        </nav>

        <!-- Contenido principal -->
        <div class="contenido-principal">

            <!-- Encabezado superior -->
            <header class="encabezado">
                <div class="encabezado-izquierda">
                    <div class="menu-lineas">
                        <i class="fas fa-bars"></i>
                    </div>
                    <h1 class="titulo-pagina">Sistema web de inventarios</h1>
                </div>

                <div class="encabezado-derecha">
                    <section class="seccion-perfil">
                        <span class="texto-perfil">Perfil</span>
                        <i class="fas fa-user"></i>

                        <section class="menu-desplegable">
                            <a href="../html/Perfil.html">Mi cuenta</a>
                            <a href="../html/Index.html">Cerrar sesión</a>
                        </section>
                    </section>
                </div>
            </header>

            <!-- Dashboard -->
            <main class="tablero">
                <div class="encabezado-pagina">
                    <h2>Sistema web de inventarios</h2>
                </div>

                <div class="rejilla-tablero">

                    <!-- Tarjeta: Órdenes de Compra -->
                    <div class="tarjeta-tablero azul">
                        <div class="icono-tarjeta">
                            <i class="fas fa-file-invoice"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Órdenes de Compra</h3>
                            <span class="numero-tarjeta">3</span>
                        </div>
                    </div>

                    <!-- Tarjeta: Compras Recibidas -->
                    <div class="tarjeta-tablero verde-azul">
                        <div class="icono-tarjeta">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Compras Recibidas</h3>
                            <span class="numero-tarjeta">2</span>
                        </div>
                    </div>

                    <!-- Tarjeta: Devoluciones -->
                    <div class="tarjeta-tablero naranja">
                        <div class="icono-tarjeta">
                            <i class="fas fa-undo"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Devoluciones</h3>
                            <span class="numero-tarjeta">1</span>
                        </div>
                    </div>

                    <!-- Tarjeta: Ventas -->
                    <div class="tarjeta-tablero azul-oscuro">
                        <div class="icono-tarjeta">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Ventas</h3>
                            <span class="numero-tarjeta">1</span>
                        </div>
                    </div>

                    <!-- Tarjeta: Proveedores -->
                    <div class="tarjeta-tablero naranja-alternativo">
                        <div class="icono-tarjeta">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Proveedores</h3>
                            <span class="numero-tarjeta">1</span>
                        </div>
                    </div>

                    <!-- Tarjeta: Productos -->
                    <div class="tarjeta-tablero morado">
                        <div class="icono-tarjeta">
                            <i class="fas fa-th-large"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Productos</h3>
                            <span class="numero-tarjeta">2</span>
                        </div>
                    </div>

                    <!-- Tarjeta: Usuarios -->
                    <div class="tarjeta-tablero rosa">
                        <div class="icono-tarjeta">
                            <i class="fas fa-user-friends"></i>
                        </div>
                        <div class="contenido-tarjeta">
                            <h3>Usuarios</h3>
                            <span class="numero-tarjeta">1</span>
                        </div>
                    </div>

                </div>
            </main>

        </div>

    </div>
</body>
</html>